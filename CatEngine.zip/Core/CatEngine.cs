using System.Windows.Forms;
using System.Drawing;

namespace CatEngine.Core
{
    class Canvas : Form
    {
        public Canvas()
        {
            this.DoubleBuffered = true;
        }
    }
    
    public abstract class CatEngine
    {
        private Vector2 ScreenSize = new Vector2(512, 512);
        private string Title = "New Game";
        private Canvas? Window = null;
        public CatEngine(Vector2 screenSize, string title)
        {
            ScreenSize = screenSize;
            Title = title;

            Window = new Canvas();
            Window.Size = ScreenSize.Size();
            Window.Text = Title;

            Application.Run(Window);
        } 

    }
}