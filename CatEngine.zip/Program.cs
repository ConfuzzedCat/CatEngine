﻿using System;
namespace CatEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Demo.");
            DemoGame game = new DemoGame();
        }
    }
}