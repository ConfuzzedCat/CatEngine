using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CatEngine.Core;

namespace CatEngine
{
    public class DemoGame : Core.CatEngine
    {
        public DemoGame() : base(new Vector2(512, 512), "CatEngine Demo"){}
    }
}